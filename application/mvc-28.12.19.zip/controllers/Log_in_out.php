<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Log_in_out extends CI_Controller {

    public function index() {
        if ($this->session->userdata('ses_logged') == "YES") {
            $this->load->model('Common_model');

            $checking_array = array("status" => 1);

            $data['all_student'] = $this->Common_model->count_all('12_insert_student_info',array("status"=>1));
            $data['all_teacher'] = $this->Common_model->count_all('13_insert_teacher_info');
            $data['all_staff'] = $this->Common_model->count_all('14_insert_staff_info');
            $data['all_book'] = $this->Common_model->count_all('42_library');
            $data['all_dormitory'] = $this->Common_model->count_all('41_insert_dormitory_info');
            $data['all_transport'] = $this->Common_model->count_all('44_transport');

            $this->load->view('admin/header');
            $this->load->view('admin/dashboard', $data);
            $this->load->view('admin/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function block_msg() {
        $data['wrong_msg'] = "Sorry ! Your ID is inactive now<br>Please Contact with Help Care";
        $this->load->view('website/login_check', $data);
    }

    public function login_check() {
        $this->form_validation->set_rules('user_id', 'User ID', 'trim|required');
        $this->form_validation->set_rules('password', 'Password', 'trim|required');
        $this->form_validation->set_rules('user_type', 'User Type', 'trim|required');

        if ($this->form_validation->run() == FALSE) {
            //Field validation failed.  User redirected to login page
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        } else {
            $this->load->model('Common_model');

            $user_id = $this->input->post('user_id');
            $password = $this->input->post('password');
            $user_type = $this->input->post('user_type');
            $status = 1;
            $right_data = 0;
            if ($user_type == "admin") {
                $table_name = "0_admin";
                $checking_array = array("admin_unique_id" => $user_id, "password" => $password);
                $result = $this->Common_model->check_value_get_data($table_name, $checking_array);
                if ($result) {
                    $right_data = 1;
                    foreach ($result as $result_info) {
                        $record_id = $result_info->record_id;
                        $unique_id = $result_info->admin_unique_id;
                        $password = $result_info->password;
                    }
                }
            } elseif ($user_type == "accounts") {
                $table_name = "14_insert_staff_info";
                $checking_array = array("staff_unique_id" => $user_id, "password" => $password);
                $result = $this->Common_model->check_value_get_data($table_name, $checking_array);
                if ($result) {
                    $right_data = 1;
                    foreach ($result as $result_info) {
                        $status = $result_info->status;
                        $record_id = $result_info->record_id;
                        $unique_id = $result_info->staff_unique_id;
                        $password = $result_info->password;

                        $library = $result_info->library;
                        $fees_collection = $result_info->fees_collection;
                        $accounting = $result_info->accounting;
                        $asset_info = $result_info->asset_info;
                        $dormitory = $result_info->dormitory;
                    }
                    $ses_data_permission = array(
                        'ses_library_access' => $library,
                        'ses_fees_collection_access' => $fees_collection,
                        'ses_accounting_access' => $accounting,
                        'ses_asset_info_access' => $asset_info,
                        'ses_dormitory_access' => $dormitory
                    );
                    $this->session->set_userdata($ses_data_permission);
                }
            } elseif ($user_type == "staff") {
                $table_name = "14_insert_staff_info";
                $checking_array = array("staff_unique_id" => $user_id, "password" => $password);
                $result = $this->Common_model->check_value_get_data($table_name, $checking_array);
                if ($result) {
                    $right_data = 1;
                    foreach ($result as $result_info) {
                        $status = $result_info->status;
                        $record_id = $result_info->record_id;
                        $unique_id = $result_info->staff_unique_id;
                        $password = $result_info->password;

                        $library = $result_info->library;
                        $fees_collection = $result_info->fees_collection;
                        $accounting = $result_info->accounting;
                        $asset_info = $result_info->asset_info;
                        $dormitory = $result_info->dormitory;
                    }
                    $ses_data_permission = array(
                        'ses_library_access' => $library,
                        'ses_fees_collection_access' => $fees_collection,
                        'ses_accounting_access' => $accounting,
                        'ses_asset_info_access' => $asset_info,
                        'ses_dormitory_access' => $dormitory
                    );
                    $this->session->set_userdata($ses_data_permission);
                }
            } elseif ($user_type == "teacher") {
                $table_name = "13_insert_teacher_info";
                $checking_array = array("teacher_unique_id" => $user_id, "password" => $password);
                $result = $this->Common_model->check_value_get_data($table_name, $checking_array);
                if ($result) {
                    $right_data = 1;
                    foreach ($result as $result_info) {
                        $status = $result_info->status;
                        $record_id = $result_info->record_id;
                        $unique_id = $result_info->teacher_unique_id;
                        $password = $result_info->password;
                    }
                }
            } elseif ($user_type == "student") {
                $table_name = "12_insert_student_info";
                $checking_array = array("student_unique_id" => $user_id, "password" => $password);
                $result = $this->Common_model->check_value_get_data($table_name, $checking_array);
                if ($result) {
                    $right_data = 1;
                    foreach ($result as $result_info) {
                        $status = $result_info->status;
                        $record_id = $result_info->record_id;
                        $unique_id = $result_info->student_unique_id;
                        $password = $result_info->password;
                    }
                }
            } elseif ($user_type == "guardian") {
                $table_name = "15_insert_guardian_info";
                $checking_array = array("guardian_unique_id" => $user_id, "password" => $password);
                $result = $this->Common_model->check_value_get_data($table_name, $checking_array);
                if ($result) {
                    $right_data = 1;
                    foreach ($result as $result_info) {
                        $status = $result_info->status;
                        $record_id = $result_info->record_id;
                        $unique_id = $result_info->guardian_unique_id;
                        $password = $result_info->password;
                    }
                }
            }

            if ($status == 0) {
                redirect('Log_in_out/block_msg', 'refresh');
            } elseif ($right_data == 1) {
                $sesdata = array(
                    'ses_record_id' => $record_id,
                    'ses_unique_id' => $unique_id,
                    'ses_password' => $password,
                    'ses_user_type' => $user_type,
                    'ses_logged' => "YES"
                );
                $this->session->set_userdata($sesdata);
                // shipan----update 11-05-2019
                $checking_array = array("status" => 1);
                $data['all_student'] = count($this->Common_model->check_value_get_data('12_insert_student_info', $checking_array));
                $data['all_teacher'] = count($this->Common_model->get_all_info('13_insert_teacher_info'));
                $data['all_staff'] = count($this->Common_model->get_all_info('14_insert_staff_info'));
                $data['all_book'] = count($this->Common_model->get_all_info('43_issue_book'));
                $data['all_dormitory'] = count($this->Common_model->get_all_info('41_insert_dormitory_info'));
                $data['all_transport'] = count($this->Common_model->get_all_info('44_transport'));

                $this->load->view('admin/header');
                $this->load->view('admin/dashboard', $data);
                $this->load->view('admin/footer');
            } else {
                $data['wrong_msg'] = "Wrong Name/Password";
                $this->load->view('website/login_check', $data);
            }
        }
    }

    public function logout() {
        $user_type = $this->session->ses_user_type;
        if ($this->session->userdata('ses_logged') == "YES") {
            if ($user_type == "staff" || $user_type == "accounts") {
                $logout_array = array('ses_record_id', 'ses_unique_id', 'ses_password', 'ses_user_type', 'ses_logged',
                    'ses_library_access', 'ses_fees_collection_access',
                    'ses_accounting_access', 'ses_asset_info_access', 'ses_dormitory_access');
            } else {
                $logout_array = array('ses_record_id', 'ses_unique_id', 'ses_password', 'ses_user_type', 'ses_logged');
            }
            $this->session->unset_userdata($logout_array);
            $this->session->sess_destroy();
            redirect('/Home', 'refresh');
        }
    }

}
