<section id="intro">
    <div class="container" style="color: black; width: 100%; padding: 0px 50px;">
        <div class="row">
            <div class="col-sm-12">
                <h1>Contact Us</h1><br>
                <div style="color: black;">
                    <p><b>School Name:</b> <?= strtoupper(DC) ?></p>
                    <p><b>Address:</b>Ramchandrapur, Muradnagar, Comilla</p>
                    <p><b>Mobile No:</b> 01714 415941</p>
                    <p><b>Web Address:</b> www.rrkhighschool.com</p>
                    <p><b>Email:</b> rrk_hschool@yahoo.com</p>
                    <p><b>EIIN Code:105993</b> </p>
                </div>
            </div>
        </div>
    </div>
</section>




