<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="container" style="color: black; width: 100%; padding: 0px 50px;">
    <div class="box box-info">
        <div class="box-header">
            <h3 class="box-title">প্রাক্তন শিক্ষার্থীদের তালিকা</h3>                                    
        </div>

        <!-- /.box-header -->
        <div class="box-body table-responsive" style="width: 98%; overflow: scroll;">
            <table id="example2" class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th style="text-align: center;">ব্যাচ নাম্বার</th>
                        <th style="text-align: center;">মৌলিক তথ্য</th>
                        <th style="text-align: center;">ঠিকানা</th>
                        <th style="text-align: center;">যোগাযোগের তথ্য</th>
                        <th style="text-align: center;">ছবি</th>
                    </tr>
                </thead>
                <tbody style="font-size: 16px;">
                    <?php
                    $count = 0;
                    foreach ($alumni_list as $alumni) {
                        ?>
                        <tr>
                            <td style="text-align: center;"><?php echo "ব্যাচ নাম্বার:" . $alumni->batch; ?></br><?php echo $alumni->educational_year; ?></td>
                            <td style="text-align: center;"><?php echo " "; ?>
                               <?php echo "নাম :" . $alumni->name; ?>
                               </br> <?php echo "বাবার নাম : " . $alumni->father_name; ?>
                               </br> <?php echo "মায়ের নাম  : " . $alumni->mother_name; ?>
                               </br> <?php echo "স্বামী/স্ত্রী :" . $alumni->spouse_name; ?>

                            </td>
                            <td style="text-align: center;"><?php echo " "; ?>
                                <?php echo "স্থায়ী ঠিকানা :" . $alumni->permanent_address; ?>
                               </br> <?php if($alumni->present_access == 0){
                                    echo  "বর্তমান ঠিকানা : " ." (গোপনীয়)" ;         
                               } 
                               else {  echo "বর্তমান ঠিকানা : " .$alumni->mobile_number;}?>

                            </td>
                            <td style="text-align: center;"><?php echo ""; ?>
                               <?php echo "ইমেইল - " . $alumni->email_id; ?>
                               </br>  <?php if($alumni->mobile_access == 0){
                                    echo  "মোবাইল নাম্বার :" ." (গোপনীয়)" ;         
                               } 
                               else {  echo "মোবাইল নাম্বার : " .$alumni->mobile_number;}?>

                            </td>
                            <td style="text-align: center;">
                                <img src="<?php echo base_url().'assets/img/alumni_images/'.$alumni->image; ?>" width="90">
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>

            </table>
        </div><!-- /.box-body -->
    </div> 
</div>