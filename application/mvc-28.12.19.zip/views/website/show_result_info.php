<div class="box box-info">
    <div class="box-header">
        <h3 class="box-title" style="color: black;">পরিক্ষার ফলাফল</h3>
    </div>
    <div id="show_info">
        <div class="box-body table-responsive" style="width: 98%; overflow: scroll; color: black;">
            <table id="example2" class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th style="text-align: center;">Roll</th>
                        <th style="text-align: center;">Student Name</th>
                        <th style="text-align: center;">Section</th>
                        <th style="text-align: center;">Total Marks</th>
                        <th style="text-align: center;">GPA</th>
                        <th style="text-align: center;">Letter Grade</th>
                        <th style="text-align: center;">Status</th>
                        <th style="text-align: center;">Merit Position</th>
                    </tr>
                </thead>
                <tbody>

                </tbody>
            </table>
        </div>
    </div>
</div>
<br>