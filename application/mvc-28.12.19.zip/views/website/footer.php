<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div style="background-color: #066; padding: 10px;
     border-radius: 0px 0px 10px 10px;" id="no_print3">
    <p style="font-size: 15px; color: white; text-align: center; font-weight: bold;
       font-family: Helvetica; margin: 0px; padding: 0px;">
    </p>
    <p style="color: white; font-size: 13px; text-align: center;">Copyright &copy; <?= date("Y")?>. Designed & Developed by <a href="http://greensoftechbd.com/" target="_blank" style="color: yellow;">GREEN SOFTWARE &
            TECHNOLOGY</a>. All rights reserved</p>
</div> 
</body>
</html>