<?php
if ($msg == "main") {
    $msg = "";
} elseif ($msg == "empty") {
    $msg = "Please fill out all required fields";
} elseif ($msg == "created") {
    $msg = "Created Successfully";
} elseif ($msg == "edit") {
    $msg = "Edited Successfully";
} elseif ($msg == "delete") {
    $msg = "Deleted Successfully";
}
?>
<aside>
    <section class="content">
        <div class="row" style="margin-top: 55px;">
            <section class="col-xs-12 connectedSortable">
                <div class="" style="color: black;">
                    
                    <div class="box-body container">
                        <p style="font-size: 20px;">প্রাক্তন শিক্ষার্থীদের তালিকা</p>
                        <p style="font-size: 20px; color: #066;"><?php echo $msg; ?></p>
                        <div class="row">
                          <div class="col-md-12 col-xs-12">
                            <div class="col-md-6 col-xs-12">
                              
        <button type="button" class="btn btn-success" style="margin-bottom: 10px" data-toggle="modal" data-target="#exampleModal">Add New Alumni </button>
                            </div>
                            <div class="col-md-6 col-xs-12" style="float: right;margin: 0px -190px;">
                              
         <!-- Search form (start) -->
   <form method='post' action="<?= base_url() ?>Show_form/loadRecord" >
     <input type='text' name='search'  value='<?= $search ?>'><input type='submit' name='submit' class="btn-success" value='Submit'>
   </form>
                            </div>
                          </div>
   <br/>
        <!-- Modal -->
        <div class="modal fade" style="font-size: 12px"; id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content" ">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Alumni Add</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
               
               <form action="<?php echo base_url('Insert/insert_alumni_intoDatabase')?>" method="post" enctype="multipart/form-data">
<fieldset>
      <legend>Educational Information</legend>
      <div class="col-sm-12 col-xs-12">
                            <div class="form-group col-sm-6 col-xs-12">
                                <label for="name" required >Batch Number</label>
                                <input type="text" class="form-control" id="name" placeholder="" name="batch" required >
                            </div>
                            <div class="form-group col-sm-6 col-xs-12">
                                <label for="name">Educational Year</label>
                                <input type="text" class="form-control" id="name" placeholder="" name="educational_year" required >
                            </div>
      </div>
                            
</fieldset>

<fieldset>
      <legend>Basic Information</legend>
      <div class="col-sm-12 col-xs-12">
                            <div class="form-group col-sm-4 col-xs-12">
                                <label for="name" >Name of Student</label>
                                <input type="text" class="form-control" id="name" placeholder="" required  name="name">
                            </div>
                            <div class="form-group col-sm-4 col-xs-12">
                                <label for="name">Spouse Name</label>
                                <input type="text" class="form-control" id="name" placeholder="" name="spouse_name">
                            </div>
                            <div class="form-group col-sm-4 col-xs-12">
                                <label for="name" required >Father Name</label>
                                <input type="text" class="form-control" id="name" placeholder="" name="father_name">
                            </div>
                            <div class="form-group col-sm-4 col-xs-12">
                                <label for="name">Mother Name</label>
                                <input type="text" class="form-control" id="name" placeholder="" name="mother_name">
                            </div>
                            <div class="form-group col-sm-4 col-xs-12">
                                <label for="name" required >Profession</label>
                                <input type="text" class="form-control" id="name" placeholder="" name="profession">
                            </div>
                            <div class="form-group col-sm-4 col-xs-12">
                                <label for="name" required >Date of Birth</label>
                                <input type="date" class="form-control" id="name" placeholder="" name="dob">
                            </div>
      </div>
                            
</fieldset>
<fieldset>
      <legend>Address</legend>
      <div class="col-sm-12 col-xs-12">
                            <div class="form-group col-sm-5 col-xs-12">
                                <label for="name">Permanent Address</label>
                               <textarea rows="3" cols="30" name="permanent_address"></textarea>
                            </div>
                            <div class="form-group col-sm-5 col-xs-12">
                                <label for="name" required >Present Address</label>
                                <textarea rows="3" cols="30" name="present_address"></textarea>
                            </div>
                            <div class="form-group col-sm-2 col-xs-12">
                        <select name="present_access" required >
                          <option value="0">Hide</option>
                          <option value="1">Show</option>
                        </select>
                        </div>

      </div>
                            
</fieldset>

<fieldset>
      <legend>Contact</legend>
      <div class="col-sm-12 col-xs-12">
                            <div class="form-group col-sm-5 col-xs-12">
                                <label for="name" >Email Address</label>
                               <input type="text" class="form-control" id="name" placeholder="" required  name="email_id">
                            </div>
                            <div class="form-group col-sm-5 col-xs-12">
                                <label for="name">Mobile Number</label>
                               <input type="text" class="form-control" id="name" placeholder="" required  name="mobile_number">
                            </div>
                             <div class="form-group col-sm-2 col-xs-12">
                        <select name="mobile_access" required >
                          <option value="0">Hide</option>
                          <option value="1">Show</option>
                        </select>
                        </div>
      </div>
                            
</fieldset>

<fieldset>
      <legend>Alumni's Photo</legend>
      <div class="col-sm-12 col-xs-12">
                            <div class="form-group col-sm-5 col-xs-12">
                                <label for="name">Image's</label>
                               <input type="file" class="form-control" id="name" placeholder="" name="image">
                            </div>
                            
</fieldset>

<div class="form-group col-sm-12 col-xs-12" style="padding: 0px 0px 0px 80%;">
                                <button type="submit" class="btn btn-primary">Add Alumni</button>
                            </div>

                           

                    </form>
              </div>
              <div class="modal-footer">
                <!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button> -->
              </div>
            </div>
          </div>
        </div>
                          

                        </div>
                    </div>
                </div>

                 <!--  <!-- /.box-header -->
       <!-- Posts List -->
   <table border='1' width='100%' style='border-collapse: collapse;'>
    <tr>
      <th>Batch</th>
      <th>Basic Info.</th>
      <th>Address</th>
      <th>Contact Info</th>
      <th>Image</th>
      <th>Action</th>
    </tr>
    <?php 
    $sno = $row+1;
    foreach($result as $data){

      $content = substr($data['permanent_address'],0, 180)." ...";
      echo "<tr >";
      echo "<td style='text-align:center;'> Batch No :".$data['batch']."</br>".$data['educational_year']."</td>";
      echo "<td style='text-align:center;'> Name :".$data['name']."</br>"."Father Name :".$data['father_name']."</br>"."Mother Name :".$data['mother_name']."</br>"."Spouse Name :".$data['spouse_name']."</td>";
      echo "<td style='text-align:center;'> Permanent Address :".$data['present_address']."</br>"."Present Address:".$data['permanent_address']."</td>";

      echo "<td style='text-align:center;'> Email :".$data['email_id']."</br> Phone :".$data['mobile_number']."</td>";
      echo "<td><img src='".base_url()."assets/img/alumni_images/".$data['image']."' width='90'></td>";
    //   print_r base_url()."assets/img/photo_gallery/".$data['image'];
?>

      <td style="text-align:center;"><a href="<?= site_url("Show_form/delete_alumni/".$data['id']) ?>" class="btn btn-danger">Delete</a></td>
      </tr>
      <?php
      $sno++;

    }
    if(count($result) == 0){
      echo "<tr>";
      echo "<td colspan='6'>No record found.</td>";
      echo "</tr>";
    }
    ?>
   </table>

   <!-- Paginate -->
   <div style='margin-top: 10px;'>
   <?= $pagination; ?>
   </div>
       <!-- /.box-body --> 
            </section>
        </div>
    </section>
</aside>