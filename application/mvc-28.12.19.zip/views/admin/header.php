<?php $user_type = $this->session->ses_user_type;?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?= DC ?></title>
    <link rel="Tab Icon" type="image/png" href="<?php echo base_url(); ?>assets/img/fab.jpg"/>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <link href="<?php echo base_url(); ?>adminlte/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <link href="<?php echo base_url(); ?>adminlte/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
    <link href="<?php echo base_url(); ?>assets/css/w3.css" rel="stylesheet" type="text/css"/>
    <link href="<?php echo base_url(); ?>adminlte/css/AdminLTE.css" rel="stylesheet" type="text/css"/>
    <link href="<?php echo base_url(); ?>assets/css/dataTables.bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/jquery-ui.css" type="text/css"/>
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap-select.min.css" type="text/css"/>
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/helper.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/custom.css">

    <!--Live Search-->
    <script src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>
</head>
<body>
<div class="container-fluid" style="position: fixed; z-index: 500; width: 100%;">
    <div class="row">
        <div class="navbar navbar-inverse" style="background-color: #066;
                     color: white; border: 0px; margin-left: 20px; margin-right: 20px;">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse"
                        data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <div class="container-fluid">
                <div class="collapse navbar-collapse row" style="padding: 8px; font-size: 16px; font-weight: bold;">
                    <?php if ($user_type == "admin") { ?>
                        <div class="col-sm-2 col-xs-12" style="text-align: center;">
                            <img src="<?php echo base_url(); ?>assets/img/logo3.png"
                                 style="width: 60px; height: 50px; border-radius: 5px;"
                                 alt="Logo">
                            <!--                                    <a style="color: white; font-size: 20px;" href="#">KARIM GROUP</a>-->
                        </div>
                        <div class="col-sm-1 col-xs-12"
                             style="color: #066; text-align: center; padding: 8px 0px 0px 0px;">
                            <a class="sub_hide" style="color: wheat;" href="<?php echo base_url(); ?>Log_in_out">Dashboard</a>
                        </div>
                        <div class="col-sm-2 col-xs-12"
                             style="color: #066; text-align: center; padding: 8px 0px 0px 0px;">
                            <a style="color: wheat; cursor: pointer;" class="dropdown-toggle sub_hide"
                               data-toggle="dropdown">Software Part<span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a class="test" href="#">
                                        <i class="fa fa-th text-red"></i>Create Option<span
                                                class="caret"></span>
                                    </a>
                                    <ul class="subtog dropdown-menu">
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/create_class/main">
                                                <i class="fa fa-angle-double-right text-red"></i> Create Class</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/create_group/main">
                                                <i class="fa fa-angle-double-right text-red"></i> Create Group</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/create_section/main">
                                                <i class="fa fa-angle-double-right text-red"></i> Create Section</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/create_shift/main">
                                                <i class="fa fa-angle-double-right text-red"></i> Create Shift</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/create_class_time/main">
                                                <i class="fa fa-angle-double-right text-red"></i> Create Class Time</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/create_session/main">
                                                <i class="fa fa-angle-double-right text-red"></i> Create Year</a>
                                        </li>
                                        <!--                                        <li style="margin: 5px; font-size: 15px; text-align: left;">-->
                                        <!--                                            <a href="-->
                                        <?php //echo base_url(); ?><!--Show_form/create_version/main">-->
                                        <!--                                                <i class="fa fa-angle-double-right text-red"></i> Create Version</a>-->
                                        <!--                                        </li>-->
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/create_subject/main">
                                                <i class="fa fa-angle-double-right text-red"></i> Create Subject</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/create_exam_type/main">
                                                <i class="fa fa-angle-double-right text-red"></i> Create Exam Type</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/create_exam_grade/main">
                                                <i class="fa fa-angle-double-right text-red"></i> Create Exam Grade</a>
                                        </li>
                                        <!--                                        <li style="margin: 5px; font-size: 15px; text-align: left;">-->
                                        <!--                                            <a href="-->
                                        <?php //echo base_url(); ?><!--Show_form/create_fee/main">-->
                                        <!--                                                <i class="fa fa-angle-double-right text-red"></i> Create Fee</a>-->
                                        <!--                                        </li> -->
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/create_designation/main"><i
                                                        class="fa fa-angle-double-right text-red"></i> Create
                                                Designation</a>
                                        </li>
                                    </ul>
                                </li>

                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a class="test" href="#">
                                        <i class="fa fa-th text-blue"></i>Student Management<span
                                                class="caret"></span>
                                    </a>
                                    <ul class="subtog dropdown-menu">
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/insert_student_info/main/1"><i
                                                        class="fa fa-angle-double-right text-blue"></i> Insert
                                                Student Info.</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/search_student"><i
                                                        class="fa fa-angle-double-right text-blue"></i> Search
                                                Student</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/student_id_card/main"><i
                                                        class="fa fa-angle-double-right text-blue"></i> ID Card</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/student_admit_card/main"><i
                                                        class="fa fa-angle-double-right text-blue"></i> Admit
                                                Card</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/student_mark_sheet/main"><i
                                                        class="fa fa-angle-double-right text-blue"></i> Progress
                                                Report</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/generate_seat_plan"><i
                                                        class="fa fa-angle-double-right text-blue"></i> Generate
                                                Seat Plan</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/class_promotion"><i
                                                        class="fa fa-angle-double-right text-blue"></i> Class
                                                Promotion</a>
                                        </li>
                                    </ul>
                                </li>

                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a class="test" href="#">
                                        <i class="fa fa-th text-orange"></i>Teacher Management<span
                                                class="caret"></span>
                                    </a>
                                    <ul class="subtog dropdown-menu">
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/insert_teacher_info/main"><i
                                                        class="fa fa-angle-double-right text-orange"></i> Insert
                                                Teacher Info.</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/teacher_id_card/main"><i
                                                        class="fa fa-angle-double-right text-orange"></i> Teacher ID
                                                Card</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/search_teacher"><i
                                                        class="fa fa-angle-double-right text-orange"></i> Search
                                                Teacher</a>
                                        </li>
                                    </ul>
                                </li>

                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a class="test" href="#">
                                        <i class="fa fa-th text-teal"></i>Staff Management<span
                                                class="caret"></span>
                                    </a>
                                    <ul class="subtog dropdown-menu">
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/insert_staff_info/main"><i
                                                        class="fa fa-angle-double-right text-teal"></i> Insert Staff
                                                Info.</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/search_staff"><i
                                                        class="fa fa-angle-double-right text-teal"></i> Search Staff</a>
                                        </li>
                                    </ul>
                                </li>

                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a class="test" href="#">
                                        <i class="fa fa-th text-green"></i>Attendence System<span
                                                class="caret"></span>
                                    </a>
                                    <ul class="subtog dropdown-menu">
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/student_attendance/main"><i
                                                        class="fa fa-angle-double-right text-green"></i> Student</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/teacher_staff_attendance/main"><i
                                                        class="fa fa-angle-double-right text-green"></i> Teacher &
                                                Staff</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/attendance_report/main"><i
                                                        class="fa fa-angle-double-right text-green"></i> Attendance
                                                Report</a>
                                        </li>
                                    </ul>
                                </li>

                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a href="<?php echo base_url(); ?>Show_form/teacher_subject_management/main">
                                        <i class="fa fa-th text-yellow"></i>
                                        <span>Subject Assignment</span>
                                    </a>
                                </li>


                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a class="test" href="#">
                                        <i class="fa fa-th text-red"></i>Marks Distribution<span
                                                class="caret"></span>
                                    </a>
                                    <ul class="subtog dropdown-menu">
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/input_marks/main"><i
                                                        class="fa fa-angle-double-right text-red"></i> Input
                                                Marks</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/marks_report"><i
                                                        class="fa fa-angle-double-right text-red"></i> Tabulation
                                                Sheet</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/send_marks_by_sms/main"><i
                                                        class="fa fa-angle-double-right text-red"></i> Sent Marks By
                                                SMS</a>
                                        </li>
                                    </ul>
                                </li>

                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a class="test" href="#">
                                        <i class="fa fa-th text-blue"></i>Result<span
                                                class="caret"></span>
                                    </a>
                                    <ul class="subtog dropdown-menu">
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/total_result"><i
                                                        class="fa fa-angle-double-right text-light-blue"></i> Total
                                                Result</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/merit_list"><i
                                                        class="fa fa-angle-double-right text-light-blue"></i> Merit
                                                List</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/fail_list"><i
                                                        class="fa fa-angle-double-right text-light-blue"></i> Fail
                                                List</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/result_at_a_glance/main"><i
                                                        class="fa fa-angle-double-right text-light-blue"></i> Result
                                                At A Glance</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/publish_result_status/main"><i
                                                        class="fa fa-angle-double-right text-light-blue"></i>
                                                Publish Result Status</a>
                                        </li>
                                    </ul>
                                </li>

                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a class="test" href="#">
                                        <i class="fa fa-th text-purple"></i>Certificates<span
                                                class="caret"></span>
                                    </a>
                                    <ul class="subtog dropdown-menu">
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/testimonial"><i
                                                        class="fa fa-angle-double-right text-purple"></i>
                                                Testimonial</a>
                                        </li>
                                    </ul>
                                </li>

                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a class="test" href="#">
                                        <i class="fa fa-th text-orange"></i>SMS System<span
                                                class="caret"></span>
                                    </a>
                                    <ul class="subtog dropdown-menu">
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/create_sms/main"><i
                                                        class="fa fa-angle-double-right text-orange"></i> Create SMS</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/send_sms_teacher"><i
                                                        class="fa fa-angle-double-right text-orange"></i> SMS to
                                                Teacher</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/send_sms_to_guardian">
                                                <i class="fa fa-angle-double-right text-orange"></i> SMS to Guardian</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/send_sms_staff"><i
                                                        class="fa fa-angle-double-right text-orange"></i> SMS to
                                                Staff</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/send_sms_governing_body"><i
                                                        class="fa fa-angle-double-right text-orange"></i> SMS to
                                                Governing Body</a>
                                        </li>
                                    </ul>
                                </li>


                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a class="test" href="#">
                                        <i class="fa fa-th text-green"></i>Library<span
                                                class="caret"></span>
                                    </a>
                                    <ul class="subtog dropdown-menu">
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/insert_book/main"><i
                                                        class="fa fa-angle-double-right text-green"></i>Insert Book</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/issue_book/main"><i
                                                        class="fa fa-angle-double-right text-green"></i> Issue Book</a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a href="<?php echo base_url(); ?>Show_form/backup/main">
                                        <i class="fa fa-th text-maroon"></i>
                                        <span>Backup</span>
                                    </a>
                                </li>

                                <!--                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">-->
                                <!--                                    <a href="-->
                                <?php //echo base_url(); ?><!--Show_form/transport/main">-->
                                <!--                                        <i class="fa fa-th text-fuchsia"></i>-->
                                <!--                                        <span>Transport</span></a>-->
                                <!--                                </li>-->
                            </ul>
                        </div>
                        <div class="col-sm-2 col-xs-12"
                             style="color: #066; text-align: center; padding: 8px 0px 0px 0px;">
                            <a style="color: wheat; cursor: pointer;" class="dropdown-toggle sub_hide"
                               data-toggle="dropdown">Accounts Part<span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a class="test" href="#">
                                        <i class="fa fa-th text-lime"></i>Fees Collection<span
                                                class="caret"></span>
                                    </a>
                                    <ul class="subtog dropdown-menu">
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/fee_collection/main"><i
                                                        class="fa fa-angle-double-right text-lime"></i>Fee
                                                Collection</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/create_fees_heads/main"><i
                                                        class="fa fa-angle-double-right text-lime"></i>Create Fees
                                                Heads</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/fee_settings/main"><i
                                                        class="fa fa-angle-double-right text-lime"></i>Class-wise
                                                Fee Settings </a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/collection_report/main"><i
                                                        class="fa fa-angle-double-right text-lime"></i>Collection
                                                Report</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/update_collection_report/main"><i
                                                        class="fa fa-angle-double-right text-lime"></i>Update Report</a>
                                        </li>
                                    </ul>
                                </li>

                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a class="test" href="#">
                                        <i class="fa fa-th text-fuchsia"></i>Bank History<span
                                                class="caret"></span>
                                    </a>
                                    <ul class="subtog dropdown-menu">
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/create_bank_name/main"><i
                                                        class="fa fa-angle-double-right text-fuchsia"></i> Create
                                                Bank Name</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/bank_deposit/main"><i
                                                        class="fa fa-angle-double-right text-fuchsia"></i> Bank
                                                Deposit</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/bank_withdraw/main"><i
                                                        class="fa fa-angle-double-right text-fuchsia"></i> Bank
                                                Withdraw</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/bank_report/main"><i
                                                        class="fa fa-angle-double-right text-fuchsia"></i> Report</a>
                                        </li>
                                    </ul>
                                </li>

                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a class="test" href="#">
                                        <i class="fa fa-th text-aqua"></i>Employee Salary<span
                                                class="caret"></span>
                                    </a>
                                    <ul class="subtog dropdown-menu">
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/create_salary_info/main"><i
                                                        class="fa fa-angle-double-right text-aqua"></i> Create
                                                Info.</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/create_salary_sheet/main"><i
                                                        class="fa fa-angle-double-right text-aqua"></i> Salary
                                                Payment</a>
                                        </li>
                                    </ul>
                                </li>


                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a class="test" href="#">
                                        <i class="fa fa-th text-red"></i>Accounting<span
                                                class="caret"></span>
                                    </a>
                                    <ul class="subtog dropdown-menu">
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/income/main"><i
                                                        class="fa fa-angle-double-right text-red"></i> Income
                                                Entry</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/expense/main"><i
                                                        class="fa fa-angle-double-right text-red"></i> Expense
                                                Entry</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/create_income_head/main"><i
                                                        class="fa fa-angle-double-right text-red"></i> Create
                                                Income Head</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/create_expense_head/main"><i
                                                        class="fa fa-angle-double-right text-red"></i> Create
                                                Expense Head</a>
                                        </li>
                                        <li style="margin: 5px; font-size: 15px; text-align: left;">
                                            <a href="<?php echo base_url(); ?>Show_form/ledger/main">
                                                <i class="fa fa-angle-double-right text-red"></i> Ledger</a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="col-sm-2 col-xs-12"
                             style="color: #066; text-align: center; padding: 8px 0px 0px 0px;">
                            <a style="color: wheat; cursor: pointer;" class="dropdown-toggle sub_hide"
                               data-toggle="dropdown">Website Part<span class="caret"></span></a>
                               <ul class="dropdown-menu">
                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a href="<?php echo base_url(); ?>Show_form/insert_news">
                                        <i class="fa fa-th text-fuchsia"></i>
                                        <span>Update News</span>
                                    </a>
                                </li>
                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a href="<?php echo base_url(); ?>Show_form/single_page_content">
                                        <i class="fa fa-th text-yellow"></i>
                                        <span>Insert Basic Info.</span>
                                    </a>
                                </li>
                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a href="<?php echo base_url(); ?>Show_form/photo_gallery">
                                        <i class="fa fa-th text-teal"></i>
                                        <span>Photo Gallery</span>
                                    </a>
                                </li>
                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a href="<?php echo base_url(); ?>Show_form/governing_body_profile">
                                        <i class="fa fa-th text"></i>
                                        <span>Insert Managing Profile</span>
                                    </a>
                                </li>
                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a href="<?php echo base_url(); ?>Show_form/class_routine">
                                        <i class="fa fa-th text-green"></i>
                                        <span>Upload Class Routine</span>
                                    </a>
                                </li>
                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a href="<?php echo base_url(); ?>Show_form/exam_routine">
                                        <i class="fa fa-th text-blue"></i>
                                        <span>Upload Exam Routine</span>
                                    </a>
                                </li>
                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a href="<?php echo base_url(); ?>Show_form/academic_calendar">
                                        <i class="fa fa-th text-red"></i>
                                        <span>Academic Calendar</span>
                                    </a>
                                </li>
                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a href="<?php echo base_url(); ?>Show_form/booklist">
                                        <i class="fa fa-th text-lime"></i>
                                        <span>Insert Booklist</span>
                                    </a>
                                </li>
                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a href="<?php echo base_url(); ?>Show_form/syllabus">
                                        <i class="fa fa-th text-orange"></i>
                                        <span>Insert Syllabus</span>
                                    </a>
                                </li>
                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a href="<?php echo base_url(); ?>Show_form/notice">
                                        <i class="fa fa-th text-green"></i>
                                        <span>Notice Board</span>
                                    </a>
                                </li>
                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a href="<?php echo base_url(); ?>Show_form/board_of_directors">
                                        <i class="fa fa-th text-aqua"></i>
                                        <span>Insert Previous Managing Committee</span>
                                    </a>
                                </li>
                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a href="<?php echo base_url(); ?>Show_form/alumni_insertion">
                                        <i class="fa fa-th text-aqua"></i>
                                        <span>Insert Alumni</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="col-sm-1 col-xs-12"
                             style="color: #066; text-align: center; padding: 8px 0px 0px 0px;">
                            <a style="color: wheat;" href="<?php echo base_url(); ?>Log_in_out/logout">Logout</a>
                        </div>
                        <div class="col-sm-2 col-xs-12" style="text-align: center; font-size: 15px; color: white;">
                            <?php echo date('l'); ?><br><?php echo date('d-M-y'); ?>
                        </div>
                    <?php } ?>
                    <?php if ($user_type == "student") { ?>
                        <div class="col-sm-2 col-xs-12"
                             style="color: #066; text-align: center; padding: 8px 0px 0px 0px;">
                            <a style="color: wheat; cursor: pointer;" class="dropdown-toggle sub_hide"
                               data-toggle="dropdown">Software Part<span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a href="<?php echo base_url(); ?>Log_in_out">
                                        <i class="fa fa-th text-teal"></i>
                                        <span>Dashboard</span>
                                    </a>
                                </li>
                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a href="<?php echo base_url(); ?>Show_form/search_student">
                                        <i class="fa fa-th text-teal"></i>
                                        <span>Profile</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="col-sm-1 col-xs-12"
                             style="color: #066; text-align: center; padding: 8px 0px 0px 0px;">
                            <a style="color: wheat;" href="<?php echo base_url(); ?>Log_in_out/logout">Logout</a>
                        </div>
                        <div class="col-sm-2 col-xs-12" style="text-align: center; font-size: 15px; color: white;">
                            <?php echo date('l'); ?><br><?php echo date('d-M-y'); ?>
                        </div>
                    <?php } ?>
                    <?php if ($user_type == "guardian") { ?>
                        <div class="col-sm-2 col-xs-12"
                             style="color: #066; text-align: center; padding: 8px 0px 0px 0px;">
                            <a style="color: wheat; cursor: pointer;" class="dropdown-toggle sub_hide"
                               data-toggle="dropdown">Software Part<span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a href="<?php echo base_url(); ?>Log_in_out">
                                        <i class="fa fa-th text-teal"></i>
                                        <span>Dashboard</span>
                                    </a>
                                </li>
                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a href="<?php echo base_url(); ?>Show_form/search_guardian">
                                        <i class="fa fa-th text-teal"></i>
                                        <span>Profile</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="col-sm-1 col-xs-12"
                             style="color: #066; text-align: center; padding: 8px 0px 0px 0px;">
                            <a style="color: wheat;" href="<?php echo base_url(); ?>Log_in_out/logout">Logout</a>
                        </div>
                        <div class="col-sm-2 col-xs-12" style="text-align: center; font-size: 15px; color: white;">
                            <?php echo date('l'); ?><br><?php echo date('d-M-y'); ?>
                        </div>
                    <?php } ?>
                    <?php if ($user_type == "teacher") { ?>
                        <div class="col-sm-2 col-xs-12"
                             style="color: #066; text-align: center; padding: 8px 0px 0px 0px;">
                            <a style="color: wheat; cursor: pointer;" class="dropdown-toggle sub_hide"
                               data-toggle="dropdown">Software Part<span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a href="<?php echo base_url(); ?>Log_in_out">
                                        <i class="fa fa-th text-teal"></i>
                                        <span>Dashboard</span>
                                    </a>
                                </li>
                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a href="<?php echo base_url(); ?>Show_form/search_teacher">
                                        <i class="fa fa-th text-teal"></i>
                                        <span>Profile</span>
                                    </a>
                                </li>
                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a href="<?php echo base_url(); ?>Show_form/input_marks/main">
                                        <i class="fa fa-th text-teal"></i>
                                        <span>Marks Input</span>
                                    </a>
                                </li>
                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a href="<?php echo base_url(); ?>Show_form/marks_report">
                                        <i class="fa fa-th text-teal"></i>
                                        <span>Marks Report</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="col-sm-1 col-xs-12"
                             style="color: #066; text-align: center; padding: 8px 0px 0px 0px;">
                            <a style="color: wheat;" href="<?php echo base_url(); ?>Log_in_out/logout">Logout</a>
                        </div>
                        <div class="col-sm-2 col-xs-12" style="text-align: center; font-size: 15px; color: white;">
                            <?php echo date('l'); ?><br><?php echo date('d-M-y'); ?>
                        </div>
                    <?php } ?>
                    <?php if ($user_type == "staff") {
                        $library_access = $this->session->ses_library_access;
                        $fees_collection_access = $this->session->ses_fees_collection_access;
                        $accounting_acess = $this->session->ses_accounting_access;
                        $asset_info_access = $this->session->ses_asset_info_access;
                        $dormitory_access = $this->session->ses_dormitory_access;
                        ?>
                        <div class="col-sm-2 col-xs-12"
                             style="color: #066; text-align: center; padding: 8px 0px 0px 0px;">
                            <a style="color: wheat; cursor: pointer;" class="dropdown-toggle sub_hide"
                               data-toggle="dropdown">Software Part<span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a href="<?php echo base_url(); ?>Log_in_out">
                                        <i class="fa fa-th text-teal"></i>
                                        <span>Dashboard</span>
                                    </a>
                                </li>
                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a href="<?php echo base_url(); ?>Show_form/search_staff">
                                        <i class="fa fa-th text-teal"></i>
                                        <span>Profile</span>
                                    </a>
                                </li>
                                <?php if ($library_access == 1) { ?>
                                    <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                        <a class="test" href="#">
                                            <i class="fa fa-th text-red"></i>Library<span
                                                    class="caret"></span>
                                        </a>
                                        <ul class="subtog dropdown-menu">
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/insert_book/main"><i
                                                            class="fa fa-angle-double-right text-green"></i>Insert Book</a>
                                            </li>
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/issue_book/main"><i
                                                            class="fa fa-angle-double-right text-green"></i> Issue Book</a>
                                            </li>
                                        </ul>
                                    </li>
                                <?php } ?>
                                <?php if ($fees_collection_access == 1) { ?>
                                    <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                        <a class="test" href="#">
                                            <i class="fa fa-th text-red"></i>Fees Collection<span
                                                    class="caret"></span>
                                        </a>
                                        <ul class="subtog dropdown-menu">
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/fee_collection/main"><i
                                                            class="fa fa-angle-double-right text-lime"></i>Fee
                                                    Collection</a>
                                            </li>
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/create_fees_heads/main"><i
                                                            class="fa fa-angle-double-right text-lime"></i>Create Fees
                                                    Heads</a>
                                            </li>
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/fee_settings/main"><i
                                                            class="fa fa-angle-double-right text-lime"></i>Class-wise
                                                    Fee Settings </a>
                                            </li>
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/collection_report/main"><i
                                                            class="fa fa-angle-double-right text-lime"></i>Collection
                                                    Report</a>
                                            </li>
                                        </ul>
                                    </li>
                                <?php } ?>
                                <?php if ($accounting_acess == 1) { ?>
                                    <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                        <a class="test" href="#">
                                            <i class="fa fa-th text-red"></i>Bank History<span
                                                    class="caret"></span>
                                        </a>
                                        <ul class="subtog dropdown-menu">
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/create_bank_name/main"><i
                                                            class="fa fa-angle-double-right text-orange"></i> Create
                                                    Bank Name</a>
                                            </li>
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/bank_deposit/main"><i
                                                            class="fa fa-angle-double-right text-orange"></i> Bank
                                                    Deposit</a>
                                            </li>
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/bank_withdraw/main"><i
                                                            class="fa fa-angle-double-right text-orange"></i> Bank
                                                    Withdraw</a>
                                            </li>
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/bank_report/main"><i
                                                            class="fa fa-angle-double-right text-orange"></i> Report</a>
                                            </li>
                                        </ul>
                                    </li>

                                    <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                        <a class="test" href="#">
                                            <i class="fa fa-th text-red"></i>Employee Salary<span
                                                    class="caret"></span>
                                        </a>
                                        <ul class="subtog dropdown-menu">
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/create_salary_info/main"><i
                                                            class="fa fa-angle-double-right text-orange"></i> Create
                                                    Info.</a>
                                            </li>
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/create_salary_sheet/main"><i
                                                            class="fa fa-angle-double-right text-orange"></i> Salary
                                                    Payment</a>
                                            </li>
                                        </ul>
                                    </li>

                                    <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                        <a class="test" href="#">
                                            <i class="fa fa-th text-red"></i>Accounting<span
                                                    class="caret"></span>
                                        </a>
                                        <ul class="subtog dropdown-menu">
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/income/main"><i
                                                            class="fa fa-angle-double-right text-orange"></i> Income
                                                    Entry</a>
                                            </li>
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/expense/main"><i
                                                            class="fa fa-angle-double-right text-orange"></i> Expense
                                                    Entry</a>
                                            </li>
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/create_income_head/main"><i
                                                            class="fa fa-angle-double-right text-orange"></i> Create
                                                    Income Head</a>
                                            </li>
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/create_expense_head/main"><i
                                                            class="fa fa-angle-double-right text-orange"></i> Create
                                                    Expense Head</a>
                                            </li>
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/ledger/main">
                                                    <i class="fa fa-angle-double-right text-orange"></i> Ledger</a>
                                            </li>
                                        </ul>
                                    </li>
                                <?php } ?>
                            </ul>
                        </div>
                        <div class="col-sm-1 col-xs-12"
                             style="color: #066; text-align: center; padding: 8px 0px 0px 0px;">
                            <a style="color: wheat;" href="<?php echo base_url(); ?>Log_in_out/logout">Logout</a>
                        </div>
                        <div class="col-sm-2 col-xs-12" style="text-align: center; font-size: 15px; color: white;">
                            <?php echo date('l'); ?><br><?php echo date('d-M-y'); ?>
                        </div>
                    <?php } ?>
                    <?php if ($user_type == "accounts") {
                        $library_access = $this->session->ses_library_access;
                        $fees_collection_access = $this->session->ses_fees_collection_access;
                        $accounting_acess = $this->session->ses_accounting_access;
                        $asset_info_access = $this->session->ses_asset_info_access;
                        $dormitory_access = $this->session->ses_dormitory_access;
                        ?>
                        <div class="col-sm-2 col-xs-12"
                             style="color: #066; text-align: center; padding: 8px 0px 0px 0px;">
                            <a style="color: wheat; cursor: pointer;" class="dropdown-toggle sub_hide"
                               data-toggle="dropdown">Software Part<span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a href="<?php echo base_url(); ?>Log_in_out">
                                        <i class="fa fa-th text-teal"></i>
                                        <span>Dashboard</span>
                                    </a>
                                </li>
                                <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                    <a href="<?php echo base_url(); ?>Show_form/search_staff">
                                        <i class="fa fa-th text-teal"></i>
                                        <span>Profile</span>
                                    </a>
                                </li>
                                <?php if ($library_access == 1) { ?>
                                    <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                        <a class="test" href="#">
                                            <i class="fa fa-th text-red"></i>Library<span
                                                    class="caret"></span>
                                        </a>
                                        <ul class="subtog dropdown-menu">
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/insert_book/main"><i
                                                            class="fa fa-angle-double-right text-green"></i>Insert Book</a>
                                            </li>
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/issue_book/main"><i
                                                            class="fa fa-angle-double-right text-green"></i> Issue Book</a>
                                            </li>
                                        </ul>
                                    </li>
                                <?php } ?>
                                <?php if ($fees_collection_access == 1) { ?>
                                    <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                        <a class="test" href="#">
                                            <i class="fa fa-th text-red"></i>Fees Collection<span
                                                    class="caret"></span>
                                        </a>
                                        <ul class="subtog dropdown-menu">
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/fee_collection/main"><i
                                                            class="fa fa-angle-double-right text-lime"></i>Fee
                                                    Collection</a>
                                            </li>
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/create_fees_heads/main"><i
                                                            class="fa fa-angle-double-right text-lime"></i>Create Fees
                                                    Heads</a>
                                            </li>
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/fee_settings/main"><i
                                                            class="fa fa-angle-double-right text-lime"></i>Class-wise
                                                    Fee Settings </a>
                                            </li>
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/collection_report/main"><i
                                                            class="fa fa-angle-double-right text-lime"></i>Collection
                                                    Report</a>
                                            </li>
                                        </ul>
                                    </li>
                                <?php } ?>
                                <?php if ($accounting_acess == 1) { ?>
                                    <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                        <a class="test" href="#">
                                            <i class="fa fa-th text-red"></i>Bank History<span
                                                    class="caret"></span>
                                        </a>
                                        <ul class="subtog dropdown-menu">
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/create_bank_name/main"><i
                                                            class="fa fa-angle-double-right text-orange"></i> Create
                                                    Bank Name</a>
                                            </li>
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/bank_deposit/main"><i
                                                            class="fa fa-angle-double-right text-orange"></i> Bank
                                                    Deposit</a>
                                            </li>
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/bank_withdraw/main"><i
                                                            class="fa fa-angle-double-right text-orange"></i> Bank
                                                    Withdraw</a>
                                            </li>
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/bank_report/main"><i
                                                            class="fa fa-angle-double-right text-orange"></i> Report</a>
                                            </li>
                                        </ul>
                                    </li>

                                    <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                        <a class="test" href="#">
                                            <i class="fa fa-th text-red"></i>Employee Salary<span
                                                    class="caret"></span>
                                        </a>
                                        <ul class="subtog dropdown-menu">
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/create_salary_info/main"><i
                                                            class="fa fa-angle-double-right text-orange"></i> Create
                                                    Info.</a>
                                            </li>
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/create_salary_sheet/main"><i
                                                            class="fa fa-angle-double-right text-orange"></i> Salary
                                                    Payment</a>
                                            </li>
                                        </ul>
                                    </li>


                                    <li class="dropdown-submenu" style="margin: 5px; font-size: 15px; text-align: left;">
                                        <a class="test" href="#">
                                            <i class="fa fa-th text-red"></i>Accounting<span
                                                    class="caret"></span>
                                        </a>
                                        <ul class="subtog dropdown-menu">
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/income/main"><i
                                                            class="fa fa-angle-double-right text-orange"></i> Income
                                                    Entry</a>
                                            </li>
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/expense/main"><i
                                                            class="fa fa-angle-double-right text-orange"></i> Expense
                                                    Entry</a>
                                            </li>
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/create_income_head/main"><i
                                                            class="fa fa-angle-double-right text-orange"></i> Create
                                                    Income Head</a>
                                            </li>
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/create_expense_head/main"><i
                                                            class="fa fa-angle-double-right text-orange"></i> Create
                                                    Expense Head</a>
                                            </li>
                                            <li style="margin: 5px; font-size: 15px; text-align: left;">
                                                <a href="<?php echo base_url(); ?>Show_form/ledger/main">
                                                    <i class="fa fa-angle-double-right text-orange"></i> Ledger</a>
                                            </li>
                                        </ul>
                                    </li>
                                <?php } ?>
                            </ul>
                        </div>
                        <div class="col-sm-1 col-xs-12"
                             style="color: #066; text-align: center; padding: 8px 0px 0px 0px;">
                            <a style="color: wheat;" href="<?php echo base_url(); ?>Log_in_out/logout">Logout</a>
                        </div>
                        <div class="col-sm-2 col-xs-12" style="text-align: center; font-size: 15px; color: white;">
                            <?php echo date('l'); ?><br><?php echo date('d-M-y'); ?>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $('.sub_hide').on("click", function () {
        $('.subtog').hide();
    });

    $('.dropdown-submenu a.test').on("click", function (e) {
        $('.subtog').hide();
        $(this).next('ul').show();
        e.stopPropagation();
        e.preventDefault();
    });
</script>
