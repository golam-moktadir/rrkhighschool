<div id="show_duplicate_msg">
    <h3 style="text-align: center; color: red;">Already Marks Given for This Subject</h3>
</div>